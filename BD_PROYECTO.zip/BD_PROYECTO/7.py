import psycopg2 as psy
from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import QApplication, QDialog, QMainWindow
from PyQt5.QtGui import QPixmap, QIcon
import sys

# 🔹 Conexión a la BD
conexion = psy.connect(
    database="Biblioteca",
    host="localhost",
    port=5432,
    user="postgres",
    password="12345"
)

cursor = conexion.cursor()

#VENTANA PRINCIPAL OSEA EL MAIN
class Main(QMainWindow):
    def __init__(self, usuario):
        super().__init__()
        uic.loadUi(r'C:\Users\eric_\Desktop\BD_PROYECTO\AV1\main.ui', self)
        self.imagen.setPixmap(QPixmap(r'C:\Users\eric_\Desktop\BD_PROYECTO\online-library'))
        self.imagen.setScaledContents(True)
        self.setWindowTitle("LibraryControl")
        self.setWindowIcon(QIcon(r'C:\Users\eric_\Desktop\BD_PROYECTO\icono.ico'))


        # 🔥 Mostrar usuario en la interfaz (asegúrate de tener un QLabel llamado label_user)
        try:
            self.saludo.setText(f"Hola Bienvenid@!,")
            self.rol.setText(f"{usuario}")
        except:
            pass


#VENTANA DE LOGEO
class MiVentana(QDialog):
    def __init__(self):
        super().__init__()
        uic.loadUi(r'C:\Users\eric_\Desktop\BD_PROYECTO\AV1\6.ui', self)
        
        self.setWindowTitle("LibraryControl - Login")
        self.setWindowIcon(QIcon(r'C:\Users\eric_\Desktop\BD_PROYECTO\icono.ico'))

        self.btn_login.clicked.connect(self.login)

    def login(self):
        usuario = self.input_user.text()
        password = self.input_pass.text()

        consulta = 'SELECT * FROM "Usuario" WHERE nombre_del_usuario = %s AND contrasena = %s'
        cursor.execute(consulta, (usuario, password))

        resultado = cursor.fetchone()

        if resultado:
            QtWidgets.QMessageBox.information(self, "Login", "Login correcto")

            #Abrir el main
            self.main = Main(usuario)
            self.main.show()

            #Cerrar login
            self.close()

        else:
            QtWidgets.QMessageBox.warning(self, "Error", "Usuario o contraseña incorrectos")


#EJECUCIÓN
app = QApplication(sys.argv)

ventana = MiVentana()
ventana.show()

app.exec()

#Cerrar conexión al salir
cursor.close()
conexion.close()